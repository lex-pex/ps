<?php $__env->startSection('feed'); ?>
<div class="row">
    <div class="col-md-12">
        <table class="table table-responsive-md">
            <tr>
                <td colspan="5"><h4> <?php echo e($title); ?> </h4></td>
                <td style="text-align:right"> <a title="Add new <?php echo e($type); ?>" href="/admin/<?php echo e($type); ?>/add"> + Add New </a> </td>
            </tr>
            <tr>
                <td colspan="6">
                    <a href="/">Main</a> | <a href="/admin">Admin Pane</a> |
                    <b><span style="text-transform:capitalize"><?php echo e($type); ?></span> List</b>
                </td>
            </tr>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td width="1%"><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><span style="background:lightblue;padding:3px"><?php echo e($item->getAttribute($parent) ? $item->getAttribute($parent)->name : 'NONE'); ?></span></td>
                <td width="10px"><span style="background:aquamarine;padding:3px"><?php echo e($item->sort_order); ?></span></td>
                <td width="10px"><?php echo $item->status ? 'Shown' : '<span style="background:pink; padding:3px">Hidden</span>'; ?></td>
                <td style="text-align:right">
                    <a href="/admin/<?php echo e($type); ?>/preview/<?php echo e($item->id); ?>">Preview</a> |
                    <a href="/admin/<?php echo e($type); ?>/edit/<?php echo e($item->id); ?>">Edit</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div style="width:100%;background:darkgray">&nbsp;</div><hr/>
        <div style="width:100%;background:darkgray">&nbsp;</div><hr/>
        <div style="width:100%;background:darkgray">&nbsp;</div>
        <img src="/img/def/def.jpg" width="100%"/>
        <div style="width:100%; background: darkgray">&nbsp;</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>