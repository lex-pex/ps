<?php $__env->startSection('feed'); ?>
<div class="row">
    <div class="col-md-12">
        <h4><?php echo e($title); ?></h4>
        <table class="table table-responsive-md">
            <tr>
                <td colspan="3" style="color:silver">
                    <a href="/">Main</a> | <a href="/admin">Admin Pane</a> | </td>
            </tr>
            <tr>
                <td colspan="3" style="color:silver">Rubric id # <?php echo e($lesson->rubric_id); ?></td>
            </tr>
            <tr>
                <td width="20px"> <?php echo e($lesson->id); ?> </td>
                <td style="text-align:center">  <?php echo e($lesson->name); ?>  </td>
                <td style="text-align:right"> <a href="/admin/lesson/edit/<?php echo e($lesson->id); ?>">Edit</a> </td>
            </tr>
                <tr><td colspan="3"><?php echo e($lesson->description); ?></td>
            </tr>
            <tr>
                <td colspan="3"><img src="<?php echo e($lesson->image ? $lesson->image : '/img/def/def.jpg'); ?>" width="100%" /></td>
            </tr>
            <tr>
                <td colspan="3"><?php echo e($lesson->text); ?></td>
            </tr>
            <tr>
                <td width="30%"> Alias </td>
                <td colspan="2"> <?php echo e($lesson->alias); ?> </td>
            </tr>
            <tr>
                <td> Status </td>
                <td colspan="2">  <?php echo e($lesson->status); ?>  </td>
            </tr>
            <tr>
                <td> Sort Order </td>
                <td colspan="2"> <?php echo e($lesson->sort_order); ?> </td>
            </tr>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>