<?php $__env->startSection('feed'); ?>
<div class="row">
    <div class="col-md-12">
        <h4><?php echo e($title); ?></h4>
        <table class="table table-responsive-md">
            <tr>
                <td colspan="3" style="color:silver">
                    <a href="/">Main</a> | <a href="/admin">Admin Pane</a> | </td>
            </tr>
            <tr>
                <td width="20px"> <?php echo e($item->id); ?> </td>
                <td style="text-align:center">  <?php echo e($item->name); ?>  </td>
                <td style="text-align:right"> <a href="/admin/part/edit/<?php echo e($item->id); ?>">Edit</a> </td>
            </tr>
                <tr><td colspan="3"><?php echo e($item->description); ?></td>
            </tr>
            <tr>
                <td colspan="3"><img src="<?php echo e($item->image ? $item->image : '/img/def/def.jpg'); ?>" width="100%" /></td>
            </tr>
            <tr>
                <td width="30%"> Alias </td>
                <td colspan="2"> <?php echo e($item->alias); ?> </td>
            </tr>
            <tr>
                <td> Status </td>
                <td colspan="2">  <?php echo e($item->status); ?>  </td>
            </tr>
            <tr>
                <td> Sort Order </td>
                <td colspan="2"> <?php echo e($item->sort_order); ?> </td>
            </tr>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>