<?php $__env->startSection('feed'); ?>
<div class="row">

    

    <?php
    if($messages = Feedback::newMessages()) {
        $color = 'tomato';
    } else
        $color = 'limegreen';
    ?>

    <a href="/admin/feedback" style="color:white">
        <div style="position:absolute;right:55px;top:-20px;padding:8px 15px 8px 15px;border-radius:50%;background:lightblue;">
            <?php echo e(Feedback::allMessages() ? Feedback::allMessages() : 0); ?>

        </div>
        <div style="position:absolute;right:5px;top:-20px;padding:8px 15px 8px 15px;border-radius:50%;background:<?php echo e($color); ?>;">
            <?php echo e(Feedback::newMessages() ? Feedback::newMessages() : 0); ?>

        </div>
    </a>
    <div class="col-md-12">
        <table class="table table-responsive-md">
            <tr>
                <td>
                    <a href="/">Main</a> | <?php $__currentLoopData = $path; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="/<?php echo e($link); ?>"><?php echo e($name); ?></a> | <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="/admin/path">Path > > > </a>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="/admin/parts">Parts</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="/admin/cats">Categories</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="/admin/rubrics">Rubrics</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="/admin/lessons">Lessons</a>
                </td>
            </tr>
            <tr style="background:silver">
                <td>
                    <a href="/admin/ads">Ads</a>
                </td>
            </tr>
            <tr style="background: silver">
                <td>
                    <a href="/admin/menu_ads">Menu Ads</a>
                </td>
            </tr>
            <tr style="background: silver">
                <td>
                    <a href="/admin/carousels">Carousels</a>
                </td>
            </tr>
        </table>
        <div style="width:100%;background:darkgray">&nbsp;</div><hr/>
        <div style="width:100%;background:darkgray">&nbsp;</div><hr/>
        <div style="width:100%;background:darkgray">&nbsp;</div>
        
        <div style="width:100%; background: darkgray">&nbsp;</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>