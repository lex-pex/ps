<!DOCTYPE html>
<html lang="ru"><head>
    <title><?php echo e($headers['pageTitle']); ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(URL::asset('favicon.ico')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/ps.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/sb.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/fa/css/fa.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('/css/font/ub.css')); ?>">
    <meta property="og:type"          content="website" />
    <meta property="og:image"         content="<?php echo e($headers['image']); ?>" />
    <meta property="og:title"         content="<?php echo e($headers['title']); ?>" />
    <meta property="og:description"   content="<?php echo e($headers['description']); ?>" />
    <meta property="og:url"           content="<?php echo e($headers['url']); ?>" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@vegansfreedom.com" />
    <meta name="twitter:title" content="<?php echo e($headers['title']); ?>" />
    <meta name="twitter:description" content="<?php echo e($headers['description']); ?>" />
    <meta name="twitter:image" content="<?php echo e($headers['image']); ?>" />
    <style>body{background:url('/img/bg/box.png') fixed;}</style>
</head>
<body>
<?php echo $__env->make('parts.sb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('parts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main role="main">
<?php echo $__env->make('parts.lesson.jumbo', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="ps-header">


    <div class="offset-lg-3 col-lg-6 offset-md-3 col-md-6 col-sm-12 col-xs-12">

        <h1><?php echo e($headers['title']); ?></h1>

        <p style="font-size: 17px;padding: 15px"><?php echo e($headers['description']); ?></p>

        <div class="ps-path">

            <?php $slash = ''?>
            <?php $__currentLoopData = $path; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <i style="color:silver"><?php echo e($slash); ?></i> <a href="<?php echo e($value); ?>"><?php echo e($key); ?></a>

                <?php $slash = '/'?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>


    
    
    



</div>
<div class="offset-lg-3 col-lg-6 offset-md-3 col-md-6 col-sm-12 col-xs-12 ps-lesson">
    
         
    
    <img src="<?php echo e($lesson->image ? $lesson->image : '/img/def/def.jpg'); ?>" style="width: 100%"/>
    <div class="ps-txt" style="white-space:pre-wrap; padding:10px">
        <?php echo e($lesson->text); ?>

    </div>
    <div class="ps-after"></div>
</div>
</main>
<?php echo $__env->make('parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="/js/jq.js"></script>
<script src="/js/bs.js"></script>
<script src="/js/ps.js"></script>
</body>
</html>
