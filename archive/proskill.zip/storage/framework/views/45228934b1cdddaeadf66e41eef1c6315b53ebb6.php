<?php $__env->startSection('feed'); ?>
<div class="row">
    <div class="col-md-12">
        <table class="table table-responsive-md">
            <tr>
                <td colspan="3">
                    <a href="/">Main</a> | <a href="/admin">Admin Pane</a> |
                    <b><span style="text-transform:capitalize"><?php echo e($linkType); ?></span> List</b>
                </td>
            </tr>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td width="20px"> <?php echo e($item->id); ?> </td>
                <td> <?php echo e($item->name); ?> </td>
                <td>
                    <a href="/admin/<?php echo e($linkType); ?>/preview/<?php echo e($item->id); ?>">Preview</a> |
                    <a href="/admin/<?php echo e($linkType); ?>/edit/<?php echo e($item->id); ?>">Edit</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div style="width:100%;background:darkgray">&nbsp;</div><hr/>
        <div style="width:100%;background:darkgray">&nbsp;</div><hr/>
        <div style="width:100%;background:darkgray">&nbsp;</div>
        <img src="/img/def/def.jpg" width="100%"/>
        <div style="width:100%; background: darkgray">&nbsp;</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>