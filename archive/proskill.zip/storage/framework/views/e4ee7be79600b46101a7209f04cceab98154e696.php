<?php $__env->startSection('feed'); ?>
<div class="row">
    <div class="col-md-12">
        <table class="table table-responsive-md">
            <tr>
                <td colspan="3">
                    <a href="/">Main</a> |
                    <a href="/admin">Admin</a> |
                    <a href="/admin/feedback">Feedback List</a> | Message
                </td>
            </tr>
            <tr>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->email); ?></td>
                <td><small><?php echo e(date('d/m/y | H:i', strtotime($item->created_at))); ?></small></td>
            </tr>
            <tr>
                <td colspan="3" style="background: white"><?php echo e($item->text); ?></td>
            </tr>
            <tr>
                <td colspan="3" style="text-align: right">
                    <button class="btn btn-danger" onclick="event.preventDefault();
                                                     document.getElementById('item-del-form').submit()">Delete</button>
                    <form id="item-del-form" action="<?php echo e(route('feedbackDel', ['item' => $item])); ?>" method="post" style="display:none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </td>
            </tr>
        </table>
        <div style="width:100%;background:darkgray">&nbsp;</div><hr/>
        <div style="width:100%;background:darkgray">&nbsp;</div><hr/>
        <div style="width:100%;background:darkgray">&nbsp;</div>
        <img src="/img/def/def.jpg" width="100%"/>
        <div style="width:100%; background: darkgray">&nbsp;</div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>