


<?php $__currentLoopData = Advert::feed($headers['url']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="ps-card offset-lg-1 col-lg-10 offset-md-1 col-md-10 col-sm-12 col-xs-12 p-0">

        <a href="<?php echo e($headers['url'] . '/' . $item->alias); ?>">
            <img src="<?php echo e($item->image ? $item->image : '/img/def/def.jpg'); ?>" style="width:100%"/>
            <div class="p-1">
                <h2><?php echo e($item->name); ?></h2>
                <hr/>
                <p><?php echo e($item->description); ?></p>
            </div>
        </a>

    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

