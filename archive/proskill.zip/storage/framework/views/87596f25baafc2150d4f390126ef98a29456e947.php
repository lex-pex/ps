<?php $__env->startSection('feed'); ?>
<?php if($group->text): ?><div class="row"><div class="col-12 p-0"><?php echo $group->text; ?></div></div><?php endif; ?>
<?php $odd = 0; ?>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($odd++ % 2 == 0): ?><div class="row"><?php endif; ?>
<div class="col-lg-6 col-md-6 p-0">
    <div class="ps-card offset-lg-1 col-lg-10 offset-md-1 col-md-10 col-sm-12 col-xs-12 p-0">
        <a href="/<?php echo e($headers['url'] . '/' . $item->alias); ?>">
            <img src="<?php echo e($item->image ? $item->image : '/img/def/def.jpg'); ?>" style="width: 100%"/>
            <div class="p-1">
                <h2><?php echo e($item->name); ?></h2>
                <hr/>
                <p><?php echo e($item->description); ?></p>
            </div>
        </a>
    </div>
</div>
<?php if($odd % 2 == 0): ?></div><?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if($odd % 2 != 0): ?>
<div class="col-lg-6 col-md-6 p-0">
    <div class="ps-card offset-lg-1 col-lg-10 offset-md-1 col-md-10 col-sm-12 col-xs-12 p-0">
        <code>реклама</code>
        <a href="https://vegansfreedom.com/health/effektivnaya_dieta_pri_prostude" target="_blank">
            <img src="/img/adv/diet.jpg" style="width:100%"/>
            <div class="p-1">
                <h2>Диета при простуде</h2>
                <p>Сезон простуды, все бегут в аптеку за пилюлями, чудо таблетками, надеясь на быстрое выздоровление. Конечно, они мог......</p>
            </div>
        </a>
    </div>
</div>
</div>
<?php endif; ?>
<div class="row"><div class="ps-after col-12 p-0"><div class="ps-carbon"></div></div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cell', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>