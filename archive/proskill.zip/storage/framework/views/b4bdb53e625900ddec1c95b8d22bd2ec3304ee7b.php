<!DOCTYPE html>
<html lang="ru"><head>
    <title><?php echo e($headers['pageTitle']); ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(asset('proger-skill-favicon.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('css/ps.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sb.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fa/css/fa.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font/ub.css')); ?>">
    <meta property="og:type"          content="website" />
    <meta property="og:image"         content="<?php echo e($headers['image'] ? $headers['image'] : '/img/def/def.jpg'); ?>" />
    <meta property="og:title"         content="<?php echo e($headers['title']); ?>" />
    <meta property="og:description"   content="<?php echo e($headers['description']); ?>" />
    <meta property="og:url"           content="<?php echo e($headers['url']); ?>" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@vegansfreedom.com" />
    <meta name="twitter:title" content="<?php echo e($headers['title']); ?>" />
    <meta name="twitter:description" content="<?php echo e($headers['image'] ? $headers['image'] : '/img/def/def.jpg'); ?>" />
    <meta name="twitter:image" content="<?php echo e($headers['image']); ?>" />
    <style>body{background:url('/img/bg/clo.jpg') fixed; }</style>
</head>
<body>
<?php echo $__env->make('parts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main role="main">
<?php echo $__env->make('parts.main.jumbo', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid ps-paralax">
        <h1>IT КУРСЫ</h1>
        <h1 style="font-size:17px">ПРОГРАММИРОВАНИЕ</h1>
        <h1 style="font-size:17px">С НУЛЯ | С АЗОВ</h1>
        <h1 style="font-size:17px">ДО ПРОФЕССИОНАЛА</h1>
    </div>
    <div class="container-fluid ps-carbon">
        <h2>профессия <b style="color:red;">IT</b></h2>
        <h2 style="color:yellow;text-shadow: 0 0 10px black; font-size: 45px; font-weight: bold">ЗАЧЕМ</h2>
    </div>
<?php echo $__env->make('parts.main.persuade-it', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid ps-paralax">
        <h2>С ЧЕГО НАЧАТЬ</h2>
        <h2>ПРОГРАММИРОВАТЬ</h2>
        <p style="font-size: 17px">
            Большой выбор языков <br/>
            программирования, но <br/>
            для заказов и работы <br/>
            среди них лидируют <br/>
            Java, JavaScript и PHP <br/>
            Почему начинать с Java
        </p>
    </div>
    <div class="ps-carbon">
        <h2>Почему язык </h2>
        <h2 style="color:red;text-shadow: 0 0 10px black; font-size: 45px; font-weight: bold">Java</h2>
    </div>
<?php echo $__env->make('parts.main.persuade-java', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid ps-paralax">
        <h2>ПЕРЕХОД НА ЛЮБОЙ</h2>
        <h2>ДРУГОЙ ЯЗЫК</h2>
        <h2>С <b style="color:red;">JAVA</b> САМЫЙ ЛЁГКИЙ</h2>
        <span style="color:yellow;">
        <h2>ПРАВИЛЬНОЕ НАЧАЛО</h2>
        <h2>ЗАЛОГ УСПЕХА</h2></span>
    </div>
</main>
<?php echo $__env->make('parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="/js/jq.js"></script>
<script src="/js/bs.js"></script>
<script src="/js/ps.js"></script>
</body>
</html>
