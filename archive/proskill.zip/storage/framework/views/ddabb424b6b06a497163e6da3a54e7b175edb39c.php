<div style="text-align:center;color:gray;text-shadow:1px 1px 1px white;padding:10px 0 0 0"> <h5>рекомендации:</h5></div>
<?php $__currentLoopData = Ad::feed($headers['url']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="ps-ad">
    <hr/><div class="p-1"><h2><?php echo e($item->name); ?></h2></div>
    <a target="_blank" href="<?php echo e($item->alias); ?>">
        <img src="<?php echo e($item->image ? $item->image : '/img/def/def.jpg'); ?>" style="width:100%"/>
        <div class="p-1"><p><?php echo e($item->description); ?></p></div>
    </a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>