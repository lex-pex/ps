<div id="sidebar" class="col-lg-5 col-md-6 col-sm-8 col-xs-12" style="display:none;">
    <ul class="sidebar-nav">
    <?php $__currentLoopData = $menu = Menu::feed(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- PARTS -->
        <li class="menu-first-item">
            <a data-target="#<?php echo e($a->urn); ?>" data-toggle="collapse" aria-expanded="true" class="ps-toggler"><?php if(count($a->list)): ?> &nbsp; <i style="color:silver" class="fa fa-angle-right fa-2x"></i> <?php else: ?> <i style="color:limegreen" class="fa fa-file-text-o fa-2x"></i> <?php endif; ?></a>
            <a href="/<?php echo e($a->urn); ?>"><?php echo e($a->name); ?></a>
        </li>
        <ul class="collapse list-group" id="<?php echo e($a->urn); ?>">
        <?php $__currentLoopData = $a->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- CATEGORIES -->
            <li class="menu-second-item">
                <a data-target="#<?php echo e(preg_replace('~/~','_',$b->urn)); ?>" data-toggle="collapse" aria-expanded="true" class="ps-toggler"><?php if(count($b->list)): ?> &nbsp; <i style="color:gray" class="fa fa-angle-right fa-2x"></i> <?php else: ?> <i style="color:limegreen" class="fa fa-file-text-o fa-2x"></i> <?php endif; ?></a>
                <a href="/<?php echo e($b->urn); ?>"><?php echo e(isset($b->name) ? $b->name : 'CATEGORY'); ?></a>
            </li>
            <ul id="<?php echo e(preg_replace('~/~','_',$b->urn)); ?>" class="collapse list-group">
            <?php $__currentLoopData = $b->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- RUBRICS -->
                <li class="menu-third-item">
                    <a data-target="#<?php echo e(preg_replace('~/~','_',$c->urn)); ?>" data-toggle="collapse" aria-expanded="true" class="ps-toggler"><?php if(count($c->list)): ?> &nbsp; <i style="color:#333" class="fa fa-angle-right fa-2x"></i> <?php else: ?> <i style="color:limegreen" class="fa fa-file-text-o fa-2x"></i> <?php endif; ?></a>
                    <a href="/<?php echo e($c->urn); ?>"><?php echo e(isset($c->name) ? $c->name : 'RUBRIC'); ?></a>
                </li>
                <ul id="<?php echo e(preg_replace('~/~','_',$c->urn)); ?>" class="collapse list-group colapsed"> <!-- LESSONS -->
                    <?php $__currentLoopData = $c->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="menu-fourth-item">
                            <a data-target="#" data-toggle="collapse" aria-expanded="true" class="ps-toggler"> <i style="color:limegreen" class="fa fa-file-text-o fa-2x"></i> </a>
                            <a href="/<?php echo e($d->urn); ?>"> <?php echo e(isset($d->name) ? $d->name : 'LESSON'); ?> </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>