<!DOCTYPE html>
<html lang="ru"><head>
    <title><?php echo e($headers['pageTitle']); ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(URL::asset('proger-skill-favicon.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/ps.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/sb.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/fa/css/fa.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('/css/font/ub.css')); ?>">
    <meta property="og:type"          content="website" />
    <meta property="og:image"         content="<?php echo e($headers['image'] ? $headers['image'] : '/img/def/def.jpg'); ?>" />
    <meta property="og:title"         content="<?php echo e($headers['title']); ?>" />
    <meta property="og:description"   content="<?php echo e($headers['description']); ?>" />
    <meta property="og:url"           content="<?php echo e(asset($headers['url'])); ?>" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@vegansfreedom.com" />
    <meta name="twitter:title" content="<?php echo e($headers['title']); ?>" />
    <meta name="twitter:description" content="<?php echo e($headers['image'] ? $headers['image'] : '/img/def/def.jpg'); ?>" />
    <meta name="twitter:image" content="<?php echo e($headers['image']); ?>" />
    <style> body{background:url('/img/bg/box.png')}</style>
</head>
<body>
<?php echo $__env->make('parts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main role="main">
<?php echo $__env->make('parts.cell.jumbo', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container-fluid m-0">
<div class="row">
<div class="col-lg-1 text-center ps-btns">
    
    <span><img src="/img/btns/1.png"/></span>
    <span><img src="/img/btns/2.png"/></span>
    <span><img src="/img/btns/3.png"/></span>
    <span><img src="/img/btns/4.png"/></span>
</div>
<div class="col-lg-8 col-md-9 col-sm-12 col-xs-12">
<div class="row">
    <div class="col-12 p-0">
        <div class="ps-header">
            <img src="<?php echo e($headers['image'] ? $headers['image'] : '/img/def/def.jpg'); ?>" style="position:absolute;left:0;top:0;width:100%;" />
            <div class="shade"></div>
            <div class="offset-lg-1 col-lg-10 offset-md-1 col-md-10 col-sm-12">
                <h1><?php echo e($headers['title']); ?></h1>
                <p style="font-size:17px;padding:15px"><?php echo e($headers['description']); ?></p>
                <div class="ps-path">
                <?php $slash = ''?>
                <?php $__currentLoopData = isset($path) ? $path : []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <i style="color:silver"><?php echo e($slash); ?></i> <a href="/<?php echo e($value); ?>"><?php echo e($key); ?></a>
                    <?php $slash = '/'?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->yieldContent('feed'); ?>
</div>
<div class="col-lg-3 col-md-3">
<?php echo $__env->make('parts.cell.rb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>
</main>
<?php echo $__env->make('parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="/js/jq.js"></script>
<script src="/js/bs.js"></script>
<script src="/js/ps.js"></script>
</body>
</html>
