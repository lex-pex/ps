<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Vegans Freedom</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/w.css">
    <link rel="stylesheet" href="css/app.css"/>
    <link rel="stylesheet" href="css/sb.css"/>
    <link rel="stylesheet" href="css/vf.css"/>

</head>
<body>

<div class="container-fluid">

    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">

        <a id="menu-toggle" class="navbar-brand" onclick="sb_open()"> <!-- href="#menu-toggle" -->
            <span class="navbar-toggler-icon"></span>
        </a>

        <a class="navbar-brand" href="#">Vegans Freedom</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault"> <!-- Hidden elements -->

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->

                <li class="nav-item"><a class="nav-link" href="">Вход</a></li>

                <li class="nav-item"><a class="nav-link" href="">Регистрация</a></li>

                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        Admin <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="http://larka.loc/logout"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            Выход
                        </a>

                        <form id="logout-form" action="" method="POST" style="display: none;">
                            <input type="hidden" name="_token" value="onu0vRaWD8daHMCXZ4wcIneLrphWnvHKn1q2lyKU">
                        </form>
                    </div>
                </li>
            </ul>
        </div>
    </nav>

    <!-- SIDEBAR -->

    <div class="w3-sidebar w3-bar-block w3-collapse w3-card w3-animate-left col-lg-2 col-md-4 col-sm-8 vf-sb" id="sidebar">
        <ul class="sidebar-nav">
            <a class="w3-bar-item w3-large w3-hide-large text-center" onclick="sb_close()">Close Menu <i class="fas fa-times"></i></a>
            <li class="sidebar-brand">
                <a href=""> Vegans Freedom </a>
            </li>
            <li>
                <a href="#">Главная</a>
            </li>
            <li> <!-- Double Inner Block -->
                <a href="#accordion" data-toggle="collapse">
                    Рецепты <i class="dropdown-toggle"></i>
                </a>
            </li>
            <ul class="collapse list-group" id="accordion">
                <li id="headingOne" class="menu-second-item">
                    <a href="#collapseOne" data-toggle="collapse" aria-expanded="true" aria-controls="collapseOne">
                        Первые блюда  <i class="dropdown-toggle"></i>
                    </a>
                </li>
                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                    <ul class="list-group">
                        <li class="menu-third-item"><a href="">Солянка</a></li>
                        <li class="menu-third-item"><a href="">Чечевичный</a></li>
                        <li class="menu-third-item"><a href="">Зеленый борщ</a></li>
                        <li class="menu-third-item"><a href="">Красный борщ</a></li>
                    </ul>
                </div>
                <li id="headingTwo" class="menu-second-item">
                    <a href="#collapseTwo" data-toggle="collapse" aria-expanded="true" aria-controls="collapseTwo">
                        Гарниры  <i class="dropdown-toggle"></i>
                    </a>
                </li>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                    <ul class="list-group">
                        <li class="menu-third-item"><a href="">Картофель</a></li>
                        <li class="menu-third-item"><a href="">Спагетти</a></li>
                        <li class="menu-third-item"><a href="">Овощое рагу</a></li>
                        <li class="menu-third-item"><a href="">Каша</a></li>
                    </ul>
                </div>
                <li id="headingThree" class="menu-second-item">
                    <a href="#collapseThree" data-toggle="collapse" aria-expanded="true" aria-controls="collapseThree">
                        Закуски  <i class="dropdown-toggle"></i>
                    </a>
                </li>
                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                    <ul class="list-group">
                        <li class="menu-third-item"><a href="">Тефтели</a></li>
                        <li class="menu-third-item"><a href="">Котлеты</a></li>
                        <li class="menu-third-item"><a href="">Соевый биток</a></li>
                        <li class="menu-third-item"><a href="">Колбаски</a></li>
                    </ul>
                </div>
            </ul>  <!-- End Double Inner Block -->
            <li>
                <a href="#">Здоровье</a>
            </li>
            <li>
                <a href="#">Советы</a>
            </li>
            <li>
                <a href="#">Гороскоп</a>
            </li>
            <li>  <!-- Inner Block -->
                <a href="#recipes" data-toggle="collapse" data-target="">
                    Упражнения <span class="dropdown-toggle"></span>
                </a>
            </li>
            <div class="collapse" id="recipes">
                <ul class="list-group">
                    <li class="menu-second-item"><a href="">Утренняя зарядка</a> </li>
                    <li class="menu-second-item"><a href="">Спортивное дыхание</a> </li>
                    <li class="menu-second-item"><a href="">Гимнастика</a> </li>
                    <li class="menu-second-item"><a href="">Тяжелая атлетика</a> </li>
                </ul>
            </div>   <!-- End Inner Block -->
            <li>
                <a href="#">About</a>
            </li>
            <li>
                <a href="#">Services</a>
            </li>
            <li>
                <a href="#">Contact</a>
            </li>
        </ul>
    </div>

    <!-- JUMBOTRON -->

    <div class="row" style="margin-top: 53px">
        <div class="p-0 offset-lg-2 col-lg-8 col-md-12 text-black-50 text-center">
            <img src="img/thee_carousel.jpg" style="width:100%;" />
            <div style="width: 100%; height: 55px; background:silver; padding: 15px; font-weight: bold; font-size: 20px">
                Menu | Some | Orders | Something <!--  background:#7FDBFF; -->
            </div>
        </div>
    </div>

    <!-- MAIN GRID -->

    <div class="row"> <!-- ROW -->
        <div class="vf-public offset-lg-2 col-lg-4 offset-md-0 col-md-6">
            <div class="card h-100 border-0">
                <img src="img/elderly.jpg" style="width: 100%" />
                <div class="p-1">
                    <img src="img/avatars/avatar_for_18.jpg" alt="Avatar"
                         class="float-left rounded-circle img-thumbnail p-0 shadow" style="width:55px;">
                    <span class="text-black-50 font-weight-bold">Роман Зодчий</span>
                    <span class="float-right text-black-50 small">
                        <span class="font-weight-bold font-italic">Здоровье</span> <br/>
                        <small class="float-right">19 мая 18</small>
                    </span>
                    <hr/>
                    <h2 class="text-center">Как дожить до СТА</h2>
                    <p>
                        Всегда прислушивайтесь к своему организму. Ваше тело всегда лучше знает,
                        что ему нужно. Оно всегда подсказывает какой продукт ему хочется. Чтобы
                        избежать зверского аппетита и перееданий, нужно делать небольшие перекусы
                        между завтраком, обедом и ужином. Также сократить количество соли и сахара, котор...
                    </p>
                </div>
                <div class="vf-footer">
                    <div class="vf-likes">
                        <i class="fas fa-eye"></i> 23
                        <i class="far fa-heart p-2"></i>5
                        &nbsp;<i class="far fa-comment"></i> 6
                    </div>
                    <div class="vf-read-more">
                        <a class="w3-btn w3-border w3-red w3-round w3-small">Читать дальше...</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="vf-public col-lg-4 col-md-6">
            <div class="card h-100 border-0">
                <img src="img/falafel.jpg" style="width: 100%"  />
                <div class="p-1">
                    <img src="img/avatars/avatar_for_12.jpg" alt="Avatar"
                         class="float-left rounded-circle img-thumbnail p-0 shadow" style="width:55px;">
                    <span class="text-black-50 font-weight-bold">Victoria Vegans</span>
                    <span class="float-right text-black-50 small">
                        <span class="font-weight-bold font-italic">Рецепты</span> <br/>
                        <small class="float-right">21 янв 18</small>
                    </span>
                    <hr/>
                    <h2 class="text-center">Фалафель</h2>
                    <p>
                        Оно всегда подсказывает какой продукт ему хочется. Чтобы
                        избежать зверского аппетита и перееданий, нужно делать небольшие перекусы
                        между завтраком, обедом и ужином. Также сократить количество соли и сахара, котор...
                        Чтобы
                        избежать зверского аппетита и перееданий, нужно делать небольшие перекусы
                        между завтраком, обедом и ужином. Также сократить количество соли и сахара, котор...
                    </p>
                </div>
                <div class="vf-footer">
                    <div class="vf-likes">
                        <i class="fas fa-eye"></i> 23
                        <i class="far fa-heart p-2"></i>5
                        &nbsp;<i class="far fa-comment"></i> 6
                    </div>
                    <div class="vf-read-more">
                        <a class="w3-btn w3-border w3-red w3-round w3-small">Читать дальше...</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row"> <!-- ROW -->

        <div class="vf-public offset-lg-2 col-lg-4 offset-md-0 col-md-6">
            <div class="card h-100 border-0">
                <img src="img/kartoshka.jpg" style="width: 100%" />
                <div class="p-1">
                    <img src="img/avatars/avatar_for_15.jpg" alt="Avatar"
                         class="float-left rounded-circle img-thumbnail p-0 shadow" style="width:55px;">
                    <span class="text-black-50 font-weight-bold">Роман Зодчий</span>
                    <span class="float-right text-black-50 small">
                        <span class="font-weight-bold font-italic">Великие Веганы</span> <br/>
                        <small class="float-right">14 июн 18</small>
                    </span>
                    <hr/>
                    <h2 class="text-center">КАРТОШЕЧКА ПО ДЕРЕВЕНСКИ С ХРУСТЯЩЕЙ КОРОЧКОЙ</h2>
                    <p class="p-1">
                        When people doing a physical task, it's easy to assess how hard they are working.
                        You can see the physical movement the sweat.... Althought the average citizen is...
                    </p>
                </div>
                <div class="vf-footer">
                    <div class="vf-likes">
                        <i class="fas fa-eye"></i> 123
                        <i class="far fa-heart p-2"></i>9
                        &nbsp;<i class="far fa-comment"></i> 3
                    </div>
                    <div  class="vf-read-more">
                        <a class="w3-btn w3-border w3-red w3-round w3-small">Читать дальше...</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="vf-public col-lg-4 col-md-6">
            <div class="card h-100 border-0 bg-public">
                <img src="img/mobi.jpg" style="width: 100%"  />
                <div class="p-1">
                    <img src="img/avatars/avatar_for_17.jpg" alt="Avatar"
                         class="float-left rounded-circle img-thumbnail p-0 shadow" style="width:55px;">
                    <span class="text-black-50 font-weight-bold">Alek Atashe</span>
                    <span class="float-right text-black-50 small">
                        <span class="font-weight-bold font-italic">Великие Веганы</span> <br/>
                        <small class="float-right">10 июн 18</small>
                    </span>
                    <hr/>
                    <h2 class="text-center">МОБИ - Веган с 1987 года</h2>
                    <p class="p-1">
                        Although the average citizen is usually annoyed by all the advertisers
                        information posted on the newspapers and magazines, also TV broadcasts...
                        Although the average citizen is usually annoyed by all the advertisers
                        information posted on the newspapers and magazines, also TV broadcasts...
                    </p>
                </div>
                <div class="vf-footer">
                    <div class="vf-likes">
                        <i class="fas fa-eye"></i> 57
                        <i class="far fa-heart p-2"></i>14
                        &nbsp;<i class="far fa-comment"></i> 8
                    </div>
                    <div class="vf-read-more">
                        <a class="w3-btn w3-border w3-red w3-round w3-small float-right">Читать дальше...</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row"> <!-- ROW -->

        <div class="vf-public offset-lg-2 col-lg-4 offset-md-0 col-md-6">
            <div class="card h-100 border-0 bg-public">
                <img src="img/psoriaz.jpg" style="width: 100%" />
                <div class="p-1">
                    <img src="img/avatars/avatar_for_18.jpg" alt="Avatar"
                         class="float-left rounded-circle img-thumbnail p-0 shadow" style="width:55px;">
                    <span class="text-black-50 font-weight-bold">Роман Зодчий</span>
                    <span class="float-right text-black-50 small">
                        <span class="font-weight-bold font-italic">Здоровье</span> <br/>
                        <small class="float-right">30 мая 18</small>
                    </span>
                    <hr/>
                    <h2 class="text-center">РАСТИТЕЛЬНАЯ ДИЕТА ВЫЛЕЧИВАЕТ ПСОРИАЗ</h2>
                    <p class="p-1">
                        When people doing a physical task, it's easy to assess how hard they are working.
                        You can see the physical movement the sweat.... Althought the average citizen is...
                    </p>
                </div>
                <div class="vf-footer">
                    <div class="vf-likes">
                        <i class="fas fa-eye"></i> 23
                        <i class="far fa-heart p-2"></i>5
                        &nbsp;<i class="far fa-comment"></i> 1
                    </div>
                    <div  class="vf-read-more">
                        <a class="w3-btn w3-border w3-red w3-round w3-small">Читать дальше...</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="vf-public col-lg-4 col-md-6">
            <div class="card h-100 border-0 bg-public">
                <img src="img/10_sekretov.jpg" style="width: 100%"  />
                <div class="p-1">
                    <img src="img/avatars/avatar_for_12.jpg" alt="Avatar"
                         class="float-left rounded-circle img-thumbnail p-0 shadow" style="width:55px;">
                    <span class="text-black-50 font-weight-bold">Victoria Vegans</span>
                    <span class="float-right text-black-50 small">
                        <span class="font-weight-bold font-italic">Здоровье</span> <br/>
                        <small class="float-right">21 янв 18</small>
                    </span>
                    <hr/>
                    <h2 class="text-center">10 СЕКРЕТОВ ЗДОРОВЬЯ ВЕГАНА</h2>
                    <p class="p-1">
                        Although the average citizen is usually annoyed by all the advertisers
                        information posted on the newspapers and magazines, also TV broadcasts...
                        Although the average citizen is usually annoyed by all the advertisers
                        information posted on the newspapers and magazines, also TV broadcasts...
                    </p>
                </div>
                <div class="vf-footer">
                    <div class="vf-likes">
                        <i class="fas fa-eye"></i> 93
                        <i class="far fa-heart p-2"></i>37
                        &nbsp;<i class="far fa-comment"></i> 7
                    </div>
                    <div class="vf-read-more">
                        <a class="w3-btn w3-border w3-red w3-round w3-small">Читать дальше...</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row"> <!-- ROW -->
        <div class="vf-public offset-lg-2 col-lg-4 offset-md-0 col-md-6">
            <div class="card h-100 border-0 bg-public">
                <img src="img/govyadina.jpg" style="width: 100%" />
                <div class="p-1">
                    <img src="img/avatars/avatar_for_18.jpg" alt="Avatar"
                         class="float-left rounded-circle img-thumbnail p-0 shadow" style="width:55px;">
                    <span class="text-black-50 font-weight-bold">Роман Зодчий</span>
                    <span class="float-right text-black-50 small">
                        <span class="font-weight-bold font-italic">Продукты</span> <br/>
                        <small class="float-right">21 янв 18</small>
                    </span>
                    <hr/>
                    <h2 class="text-center">Говядина против бобов! Кто выиграет?</h2>
                    <p class="p-1">
                        When people doing a physical task, it's easy to assess how hard they are working.
                        You can see the physical movement the sweat.... Althought the average citizen is...
                    </p>
                </div>
                <div class="vf-footer">
                    <div class="vf-likes">
                        <i class="fas fa-eye"></i> 23
                        <i class="far fa-heart p-2"></i>5
                        &nbsp;<i class="far fa-comment"></i> 6
                    </div>
                    <div class="vf-read-more">
                        <a class="w3-btn w3-border w3-red w3-round w3-small">Читать дальше...</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="vf-public col-lg-4 col-md-6">
            <div class="card h-100 border-0 bg-public">
                <img src="img/yaic.jpg" style="width: 100%"  />
                <div class="p-1">
                    <img src="img/avatars/avatar_for_12.jpg" alt="Avatar"
                         class="float-left rounded-circle img-thumbnail p-0 shadow" style="width:55px;">
                    <span class="text-black-50 font-weight-bold">Victoria Vegans</span>
                    <span class="float-right text-black-50 small">
                        <span class="font-weight-bold font-italic">Продукты</span> <br/>
                        <small class="float-right">7 фев 18</small>
                    </span>
                    <hr/>
                    <h2 class="text-center">5 причин отказаться от яиц</h2>
                    <p class="p-1">
                        Although the average citizen is usually annoyed by all the advertisers
                        information posted on the newspapers and magazines, also TV broadcasts...
                        Although the average citizen is usually annoyed by all the advertisers
                        information posted on the newspapers and magazines, also TV broadcasts...
                    </p>
                </div>
                <div class="vf-footer">
                    <div class="vf-likes">
                        <i class="fas fa-eye"></i> 93
                        <i class="far fa-heart p-2"></i>37
                        &nbsp;<i class="far fa-comment"></i> 5
                    </div>
                    <div class="vf-read-more">
                        <a class="w3-btn w3-border w3-red w3-round w3-small">Читать дальше...</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row"> <!-- ROW -->
        <div class="vf-public offset-lg-2 col-lg-4 offset-md-0 col-md-6">
            <div class="card h-100 border-0 bg-public">
                <img src="img/kotleta.jpg" style="width: 100%" />
                <div class="p-1">
                    <img src="img/avatars/avatar_for_18.jpg" alt="Avatar"
                         class="float-left rounded-circle img-thumbnail p-0 shadow" style="width:55px;">
                    <span class="text-black-50 font-weight-bold">Роман Зодчий</span>
                    <span class="float-right text-black-50 small">
                        <span class="font-weight-bold font-italic">Рецепты</span> <br/>
                        <small class="float-right">21 янв 18</small>
                    </span>
                    <hr/>
                    <h2 class="text-center">Котлета для веган бургера</h2>
                    <p class="p-1">
                        When people doing a physical task, it's easy to assess how hard they are working.
                        You can see the physical movement the sweat.... Althought the average citizen is...
                    </p>
                </div>
                <div class="vf-footer">
                    <div class="vf-likes">
                        <i class="fas fa-eye"></i> 23
                        <i class="far fa-heart p-2"></i>5
                        &nbsp;<i class="far fa-comment"></i> 4
                    </div>
                    <div class="vf-read-more">
                        <a class="w3-btn w3-border w3-red w3-round w3-small">Читать дальше...</a>
                    </div>

                </div>
            </div>
        </div>

        <div class="vf-public col-lg-4 col-md-6">
            <div class="card h-100 border-0 bg-public">
                <img src="img/babumyan.jpg" style="width: 100%"  />
                <div class="p-1">
                    <img src="img/avatars/avatar_for_12.jpg" alt="Avatar"
                         class="float-left rounded-circle img-thumbnail p-0 shadow" style="width:55px;">
                    <span class="text-black-50 font-weight-bold">Victoria Vegans</span>
                    <span class="float-right text-black-50 small">
                        <span class="font-weight-bold font-italic">Знаменитые Веганы</span> <br/>
                        <small class="float-right">21 янв 18</small>
                    </span>
                    <hr/>
                    <h2 class="text-center">Невероятно сильный Веган Бабумян</h2>
                    <p class="p-1">
                        Although the average citizen is usually annoyed by all the advertisers
                        information posted on the newspapers and magazines, also TV broadcasts...

                        Although the average citizen is usually annoyed by all the advertisers
                        information posted on the newspapers and magazines, also TV broadcasts...
                    </p>
                </div>
                <div class="vf-footer">
                    <div class="vf-likes">
                        <i class="fas fa-eye"></i> 93
                        <i class="far fa-heart p-2"></i>17
                        &nbsp;<i class="far fa-comment"></i> 3
                    </div>
                    <div class="vf-read-more">
                        <a class="w3-btn w3-border w3-red w3-round w3-small">Читать дальше...</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row"> <!-- ROW -->
        <div class="vf-public offset-lg-2 col-lg-4 offset-md-0 col-md-6">
            <div class="card h-100 border-0 bg-public">
                <img src="img/karnizm.jpg" style="width: 100%" />
                <div class="p-1">
                    <img src="img/avatars/avatar_for_18.jpg" alt="Avatar"
                         class="float-left rounded-circle img-thumbnail p-0 shadow" style="width:55px;">
                    <span class="text-black-50 font-weight-bold">Роман Зодчий</span>
                    <span class="float-right text-black-50 small">
                        <span class="font-weight-bold font-italic">Новости</span> <br/>
                        <small class="float-right">21 янв 18</small>
                    </span>
                    <hr/>
                    <h2 class="text-center">Веганство, или Карнизм? Травоед против Мясоеда</h2>
                    <p class="p-1">
                        When people doing a physical task, it's easy to assess how hard they are working.
                        You can see the physical movement the sweat.... Althought the average citizen is...
                    </p>
                </div>
                <div class="vf-footer">
                    <div class="vf-likes">
                        <i class="fas fa-eye"></i> 23
                        <i class="far fa-heart p-2"></i>5
                        &nbsp;<i class="far fa-comment"></i> 2
                    </div>
                    <div class="vf-read-more">
                        <a class="w3-btn w3-border w3-red w3-round w3-small">Читать дальше...</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="vf-public col-lg-4 col-md-6">
            <div class="card h-100 border-0 bg-public">
                <img src="img/protein.jpg" style="width: 100%"  />
                <div class="p-1">
                    <img src="img/avatars/avatar_for_17.jpg" alt="Avatar"
                         class="float-left rounded-circle img-thumbnail p-0 shadow" style="width:55px;">
                    <span class="text-black-50 font-weight-bold">Alek Atashe</span>
                    <span class="float-right text-black-50 small">
                        <span class="font-weight-bold font-italic">Питание</span> <br/>
                        <small class="float-right">21 янв 18</small>
                    </span>
                    <hr/>
                    <h2 class="text-center">ПРОТЕИН ИСТОЧНИКИ И ДОЗИРОВКИ БЕЛКА</h2>
                    <p class="p-1">
                        Although the average citizen is usually annoyed by all the advertisers
                        information posted on the newspapers and magazines, also TV broadcasts...

                        Although the average citizen is usually annoyed by all the advertisers
                        information posted on the newspapers and magazines, also TV broadcasts...
                    </p>
                </div>
                <div class="vf-footer">
                    <div class="vf-likes">
                        <i class="fas fa-eye"></i> 93
                        <i class="far fa-heart p-2"></i>24
                        &nbsp;<i class="far fa-comment"></i> 1
                    </div>
                    <div class="vf-read-more">
                        <a class="w3-btn w3-border w3-red w3-round w3-small">Читать дальше...</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pagination -->

    <div class="row">
        <div class="p-0 offset-lg-2 col-lg-8 col-md-12 w3-grey">
            <div class="mt-2 mb-0">
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-center">
                        <li class="page-item">
                            <a class="page-link" href="#" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                                <span class="sr-only">Previous</span>
                            </a>
                        </li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item active"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#">4</a></li>
                        <li class="page-item"><a class="page-link" href="#">5</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                                <span class="sr-only">Next</span>
                            </a>
                        </li>
                    </ul>
                </nav>

            </div>
        </div>
    </div>

    <!-- FOOTER -->

    <div class="row">

        <div class="p-0 offset-lg-2 col-lg-8 col-md-12 bg-dark text-white-50 text-center">

            <br/>
            <div style="display: inline; text-decoration: underline">
                <p>&copy; 2018 Lexis <sup><img src="img/logo_gray.png" style="width:27px;" /></sup> Digital Studio</p>
            </div>
            <br/>

        </div>
    </div>

    <!-- RIGHT BAR -->

    <div class="vf-right-bar w3-grey w3-sidebar w3-collapse w3-animate-right col-lg-2 col-md-4 p-1">

        <div class="card m-1">
            <div class="card-header text-center p-0">
                <h3>О нас</h3>
            </div>
            <img src="img/onas.png" width="100%" />
            <div class="card-body p-1">
                Mobiles phones have ingrained in our everyday life with strong and durable qualities.
            </div>
        </div>

        <div class="card m-1">
            <div class="card-header text-center p-0">
                <h3>The health</h3>
            </div>
            <img src="img/zdorovie.png" width="100%" />
            <div class="card-body p-1">
                Mobiles phones have ingrained in our everyday life with strong and durable qualities.
            </div>
        </div>

        <div class="card m-1">
            <div class="card-header text-center p-0">
                <h3>Any title</h3>
            </div>
            <img src="img/monkey.jpg" width="100%" />
            <div class="card-body p-1">
                Mobiles phones have ingrained in our everyday life with strong and durable qualities.
            </div>
        </div>
        <div>
            <br/>&nbsp;<br/>
            <br/>&nbsp;<br/>
        </div>
    </div>
</div>
<script src="js/jq.js"></script>
<script src="js/bs.js"></script>
<script src="js/vf.js"></script></body>
</html>













