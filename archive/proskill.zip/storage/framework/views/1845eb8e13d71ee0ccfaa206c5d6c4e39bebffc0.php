<div id="sidebar" class="col-lg-5 col-md-6 col-sm-8 col-xs-12" style="display:none;">
    <ul class="sidebar-nav">
    <?php $__currentLoopData = $menu = Menu::feed(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- PARTS -->
        <li class="menu-first-item">
            <a data-target="#<?php echo e($a->urn); ?>" data-toggle="collapse" aria-expanded="true" class="ps-toggler"><?php if(count($a->list)): ?> &nbsp; <i style="color:silver" class="fa fa-angle-right fa-2x"></i> <?php else: ?> <i style="color:limegreen" class="fa fa-file-text-o fa-2x"></i> <?php endif; ?></a>
            <a href="/<?php echo e($a->urn); ?>"><?php echo e($a->name); ?></a>
        </li>
        <ul class="collapse list-group" id="<?php echo e($a->urn); ?>">
        <?php $__currentLoopData = $a->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- CATEGORIES -->
            <li class="menu-second-item">
                <a data-target="#<?php echo e(preg_replace('~/~','_',$b->urn)); ?>" data-toggle="collapse" aria-expanded="true" class="ps-toggler"><?php if(count($b->list)): ?> &nbsp; <i style="color:gray" class="fa fa-angle-right fa-2x"></i> <?php else: ?> <i style="color:limegreen" class="fa fa-file-text-o fa-2x"></i> <?php endif; ?></a>
                <a href="/<?php echo e($b->urn); ?>"><?php echo e(isset($b->name) ? $b->name : 'CATEGORY'); ?></a>
            </li>
            <ul id="<?php echo e(preg_replace('~/~','_',$b->urn)); ?>" class="collapse list-group">
            <?php $__currentLoopData = $b->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- RUBRICS -->
                <li class="menu-third-item">
                    <a data-target="#<?php echo e(preg_replace('~/~','_',$c->urn)); ?>" data-toggle="collapse" aria-expanded="true" class="ps-toggler"><?php if(count($c->list)): ?> &nbsp; <i style="color:#333" class="fa fa-angle-right fa-2x"></i> <?php else: ?> <i style="color:limegreen" class="fa fa-file-text-o fa-2x"></i> <?php endif; ?></a>
                    <a href="/<?php echo e($c->urn); ?>"><?php echo e(isset($c->name) ? $c->name : 'RUBRIC'); ?></a>
                </li>
                <ul id="<?php echo e(preg_replace('~/~','_',$c->urn)); ?>" class="collapse list-group"> <!-- LESSONS colapsed -->
                    <?php $__currentLoopData = $c->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="menu-fourth-item">
                            <a data-target="#" data-toggle="collapse" aria-expanded="true" class="ps-toggler"> <i style="color:limegreen" class="fa fa-file-text-o fa-2x"></i> </a>
                            <a href="/<?php echo e($d->urn); ?>"> <?php echo e(isset($d->name) ? $d->name : 'LESSON'); ?> </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<div class="col-12 pl-5 pr-5"><!-- Menu Ads Area -->
    <div style="text-align:center;color:gray;text-shadow:1px 1px 1px white;padding:10px 0 0 0"> <h5>рекомендации:</h5></div>
    <?php $__currentLoopData = Ad::feedMenu($headers['url']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="ps-ad">
            <div class="p-1"><h2><?php echo e($item->name); ?></h2></div>
            <a target="_blank" href="<?php echo e($item->alias); ?>">
                <img src="<?php echo e($item->image ? $item->image : '/img/def/def.jpg'); ?>" style="width:100%"/>
                <div class="p-1"><p><?php echo e($item->description); ?></p></div>
            </a>
        </div><hr/>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!-- End Menu Ads Area -->
<div class="ps-carbon">&copy; Proger Skill 2018</div><div style="height:45px"></div><!-- Spaces for Menu Ads Area -->
</div><!-- sidebar -->
<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark"> <!-- fixed-top -->
    <a id="menu-toggle" class="navbar-brand" onclick="sb_toggle()"> <!-- href="#menu-toggle" -->
        <span style="color:white" id="btn-toggler" class="fa fa-bars"></span> <!-- navbar-toggler-icon -->
    </a>
    <a class="navbar-brand" href="/">Proger Skill</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nbid" aria-controls="nbid" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nbid">
        <ul class="navbar-nav mr-auto">
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!count($a->list)): ?>
            <li class="nav-item">
                <a class="nav-link" href="/<?php echo e($a->urn); ?>"><?php echo e($a->name); ?></a>
            </li>
        <?php else: ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="" id="#<?php echo e($a->urn); ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e($a->name); ?></a>
                <div class="dropdown-menu" aria-labelledby="#<?php echo e($a->urn); ?>">
                    <a class="dropdown-item" href="/<?php echo e($a->urn); ?>"><?php echo e($a->name); ?></a>
                    <div class="dropdown-divider"></div> <!-- Main Link -->
                    <?php $__currentLoopData = $a->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="dropdown-item" href="/<?php echo e($b->urn); ?>"><?php echo e($b->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</nav>
<div style="height:53px"></div><!-- spacer -->