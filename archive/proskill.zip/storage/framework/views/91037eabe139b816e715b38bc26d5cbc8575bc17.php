<!DOCTYPE html>
<html lang="ru"><head>
    <title><?php echo e($headers['pageTitle']); ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(URL::asset('favicon.ico')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/ps.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/sb.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/fa/css/fa.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('/css/font/ub.css')); ?>">
    <meta property="og:type"          content="website" />
    <meta property="og:image"         content="<?php echo e($headers['image']); ?>" />
    <meta property="og:title"         content="<?php echo e($headers['title']); ?>" />
    <meta property="og:description"   content="<?php echo e($headers['description']); ?>" />
    <meta property="og:url"           content="<?php echo e($headers['url']); ?>" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@vegansfreedom.com" />
    <meta name="twitter:title" content="<?php echo e($headers['title']); ?>" />
    <meta name="twitter:description" content="<?php echo e($headers['description']); ?>" />
    <meta name="twitter:image" content="<?php echo e($headers['image']); ?>" />
    <style> body{background:url('/img/bg/box.png') fixed;}</style>
</head>
<body>
<?php echo $__env->make('parts.sb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('parts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main role="main">
<?php echo $__env->make('parts.lesson.jumbo', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container-fluid">

<div class="row">

<div class="col-lg-1 text-center">

    
    
    
    
    <span><img style="box-shadow:5px 5px 0 silver;width: 50px; margin: 7px; border-radius: 50%" src="img/ava/1.png"/> </span>
    <span><img style="box-shadow:5px 5px 0 silver;width: 50px; margin: 7px; border-radius: 50%" src="img/ava/2.png"/> </span>
    <span><img style="box-shadow:5px 5px 0 silver;width: 50px; margin: 7px; border-radius: 50%" src="img/ava/3.png"/> </span>
    <span><img style="box-shadow:5px 5px 0 silver;width: 50px; margin: 7px; border-radius: 50%" src="img/ava/4.png"/> </span>

</div>

<div class="offset-lg- col-lg-8 col-md-9 col-sm-12 col-xs-12">
    <div class="row">
        <div class="col-12 p-0">
            <div class="ps-header">
                <div class="offset-lg-2 col-lg-8 offset-md-1 col-md-10 col-sm-12">
                    <h1><?php echo e($headers['title']); ?></h1>
                    <p style="font-size: 17px;padding: 15px"><?php echo e($headers['description']); ?></p>
                    <div class="ps-path">
                    <?php $slash = ''?>
                    <?php $__currentLoopData = $path; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <i style="color:silver"><?php echo e($slash); ?></i> <a href="<?php echo e($value); ?>"><?php echo e($key); ?></a>
                        <?php $slash = '/'?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $odd = 0; ?>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($odd++ % 2 == 0): ?><div class="row"><?php endif; ?>
        <div class="col-lg-6 col-md-6 p-0">
            <div class="ps-card offset-lg-1 col-lg-10 offset-md-1 col-md-10 col-sm-12 col-xs-12 p-0">
                <a href="<?php echo e($headers['url'] . '/' . $item->alias); ?>">
                    <img src="<?php echo e($item->image ? $item->image : '/img/def/def.jpg'); ?>" style="width: 100%"/>
                    <div class="p-1">
                        <h2><?php echo e($item->name); ?></h2>
                        <hr/>
                        <p><?php echo e($item->description); ?></p>
                    </div>
                </a>
            </div>
        </div>
<?php if($odd % 2 == 0): ?></div><?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="row">
        <div class="ps-after col-12 p-0">
            <div class="ps-carbon"></div>
        </div>
    </div>

</div>

<div class="col-lg-3 col-md-3">

    <hr/>

    <p>When people are doing a physical task, it's
        easy to assess how hard they are working...</p>

    <img src="img/draft/classes.jpg" width="100%" style="width:100%;"/>

    <p>When people are doing a physical task, it's
        easy to assess how hard they are working...</p>

    <hr/>

    <p>When people are doing a physical task, it's
        easy to assess how hard they are working...</p>

    <img src="img/bg/open-iron-man.jpg" width="100%" style="width:100%;"/>

    <p>When people are doing a physical task, it's
        easy to assess how hard they are working...</p>

    <hr/>

    <p>When people are doing a physical task, it's
        easy to assess how hard they are working...</p>

    <img src="img/def/def.jpg" width="100%" style="width:100%;"/>

    <p>When people are doing a physical task, it's
        easy to assess how hard they are working...</p>

    <hr/>

</div>

</div>

</div>



</main>
<?php echo $__env->make('parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="/js/jq.js"></script>
<script src="/js/bs.js"></script>
<script src="/js/ps.js"></script>
</body>
</html>
