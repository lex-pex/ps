<?php $__env->startSection('feed'); ?>
<div class="row">
    <div class="col-md-12">
        <table class="table table-responsive-md">
            <tr>
                <td colspan="2"><h4> <?php echo e($title); ?> </h4></td>
                <td style="text-align:right"> <a title="Add new lesson" href="/admin/lesson/add"> + Add New </a> </td>
            </tr>
            <tr>
                <td colspan="3">
                    <a href="/">Main</a> | <?php $__currentLoopData = $path; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="/<?php echo e($link); ?>"><?php echo e($name); ?></a> | <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
            <tr>
                <td width="20px"> <?php echo e($lesson->id); ?> </td>
                <td style="text-align:center"><b><?php echo e($lesson->name); ?></b></td>
                <td style="text-align:right"> <a href="/admin/lesson/edit/<?php echo e($lesson->id); ?>">Edit</a> </td>
            </tr>
            <tr>
                <td colspan="3" style="white-space: pre-wrap"><?php echo e($lesson->description); ?></td>
            </tr>
            <tr>
                <td colspan="3" style="white-space: pre-wrap">
                    <img src="<?php echo e($lesson->image ? $lesson->image : '/img/def/def.jpg'); ?>" width="100%" />
                </td>
            </tr>
            <tr>
                <td colspan="3" style="white-space: pre-wrap"><?php echo e($lesson->text); ?></td>
            </tr>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>