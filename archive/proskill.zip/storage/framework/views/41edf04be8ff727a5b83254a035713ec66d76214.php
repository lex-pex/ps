<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark"> <!-- fixed-top -->

    <a id="menu-toggle" class="navbar-brand" onclick="sb_toggle()"> <!-- href="#menu-toggle" -->
        <span style="color:white" id="btn-toggler" class="fa fa-bars"></span> <!-- navbar-toggler-icon -->
    </a>

    <a class="navbar-brand" href="/">Proger Skill</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nbid" aria-controls="nbid" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="nbid">
        <ul class="navbar-nav mr-auto">

            
                
            

            
                
            

            

            

                
                    
                

            



            



            <div class="dropdown-divider"></div>

            <li class="nav-item">
                <a class="nav-link" href="/about">PS проект</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="/java">Котакты</a>
            </li>

            <div class="dropdown-divider"></div>

            <li class="nav-item">
                <a class="nav-link" href="#">Link</a>
            </li>
            <li class="nav-item">
                <a class="nav-link disabled" href="#">Disabled</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="http://example.com" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</a>
                <div class="dropdown-menu" aria-labelledby="dropdown01">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                </div>
            </li>

        </ul>

        
            
            
        

    </div>

</nav>
<div style="height:53px"></div><!-- spacer -->