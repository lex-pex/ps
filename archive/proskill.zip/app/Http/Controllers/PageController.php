<?php

namespace App\Http\Controllers;

use App\Models\Feedback;
use Illuminate\Http\Request;

class PageController extends Controller
{

    public function main() {
        return view('main', [
            'headers' => $this->getMainHeaders(),
        ]);
    }

    public function about() {
        return view('pages.about', [
            'headers' => $this->getAboutHeaders(),
            'path' => ['Главная' => '/', 'О проекте PS' => 'about']
        ]);
    }

    public function contacts() {
        return $this->contactsForm();
    }

    public function feedback(Request $request) {
        $this->validate($request, [
            'name' => 'required|min:2|max:100',
            'email' => 'email',
            'text' => 'required|min:3|max:510',
        ]);
        $data = $request->except('_token');
        $feedback = new Feedback();
        $feedback->fill($data);
        $feedback->save();
        return $this->contactsForm(true);
    }

    private function contactsForm($is_sent = false) {
        $sent = $is_sent;
        return view('pages.contacts', [
            'isSent' => $sent,
            'headers' => $this->getContactHeaders(),
            'path' => ['Главная' => '/', 'Контакты проекта PS' => 'contacts']
        ]);
    }

    public function getMainHeaders() {
        return [
            'pageTitle' => 'Proger Skill',
            'url' => '/',
            'title' => 'Main title',
            'description' => 'Это образовательный проект о программировании, цель которого рассказать простыми словами о сложном. Пусть курс очередной, но далеко не самый заурядный, тут есть много полезных советов, а главное правильный путь изучения программирования на примере языка Java',
            'image' => ''
        ];
    }

    public function getAboutHeaders() {
        return [
            'pageTitle' => 'О проекте PS | Proger Skill',
            'url' => 'about',
            'title' => 'О проекте PS',
            'description' => 'Это образовательный проект о программировании, цель которого рассказать простыми словами о сложном. Пусть курс очередной, но далеко не самый заурядный, тут есть много полезных советов, а главное правильный путь изучения программирования на примере языка Java',
            'image' => '/img/def/def.jpg'
        ];
    }

    public function getContactHeaders() {
        return [
            'pageTitle' => 'Контакты проекта PS | Proger Skill',
            'url' => 'contacts',
            'title' => 'Связь с проектом PS',
            'description' =>
                'Образовательный проект о программировании Proger Skill. По вопросам к администрации Вы можете связаться посредством формы, указав Ваш контактный Email',
            'image' => '/img/def/def.jpg'
        ];
    }

}





















