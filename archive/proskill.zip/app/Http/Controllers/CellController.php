<?php

namespace App\Http\Controllers;

use App\Models\Part;

class CellController extends Controller
{
    public function part($part)
    {
        if (!$part = Part::where('alias', $part)->first()) return abort(404);
        $path = $part->alias;
        return view('pages.list', [
            'type' => 'part',
            'headers' => $this->getItemHeaders($part, $path),
            'group' => $part,
            'items' => $part->categories->where('status', 1),
            'path' => ['Главная' => '', $part->name => $part->alias]
        ]);
    }

    public function category($part, $category)
    {
        if (!$part = Part::where('alias', $part)->first()) return abort(404);
        if (!$cat = $part->categories->where('alias', $category)->first()) return abort(404);
        $path = $part->alias . '/' . $cat->alias;
        return view('pages.list', [
            'type' => 'category',
            'headers' => $this->getItemHeaders($cat, $path),
            'group' => $cat,
            'items' => $cat->rubrics->where('status', 1),
            'path' => ['Главная' => '',
                $part->name => $part->alias,
                $cat->name => $path
            ]
        ]);
    }

    public function rubric($part, $category, $rubric)
    {
        if (!$part = Part::where('alias', $part)->first()) return abort(404);
        if (!$cat = $part->categories->where('alias', $category)->first()) return abort(404);
        if (!$rubric = $cat->rubrics->where('alias', $rubric)->first()) return abort(404);
        $path = $part->alias . '/' . $cat->alias . '/' . $rubric->alias;
        return view('pages.list', [
            'type' => 'rubric',
            'headers' => $this->getItemHeaders($rubric, $path),
            'group' => $rubric,
            'items' => $rubric->lessons->where('status', 1),
            'path' => ['Главная' => '',
                $part->name => $part->alias,
                $cat->name => $part->alias . '/' . $cat->alias,
                $rubric->name => $path
            ]
        ]);
    }

    public function lesson($part, $category, $rubric, $lesson)
    {
        if (!$part = Part::where('alias', $part)->first()) return abort(404);
        if (!$cat = $part->categories->where('alias', $category)->first()) return abort(404);
        if (!$rubric = $cat->rubrics->where('alias', $rubric)->first()) return abort(404);
        if (!$lesson = $rubric->lessons->where('alias', $lesson)->first()) return abort(404);
        $path = $part->alias . '/' . $cat->alias . '/' . $rubric->alias . '/' . $lesson->alias;
        return view('pages.les', [
            'type' => 'lesson',
            'headers' => $this->getItemHeaders($lesson, $path),
            'lesson' => $lesson,
            'path' => ['Главная' => '',
                $part->name => asset($part->alias),
                $cat->name => asset($part->alias . '/' . $cat->alias),
                $rubric->name => $part->alias . '/' . $cat->alias . '/' . $rubric->alias,
                $lesson->name => $path
            ]
        ]);
    }

    public function getItemHeaders($item, $path = '')
    {
        return [
            'pageTitle' => $item->name . ' | Proger Skill',
            'url' => $path,
            'title' => $item->name,
            'description' => $item->description,
            'image' => $item->image
        ];
    }
}
