<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Request as R;
use Illuminate\Support\Facades\Auth;
use App\Models\DailyVisit;
use App\Models\Visit;

class Counter
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $count = false;
        if(($u = Auth::user()) == null) $count = true;
        elseif($u->role == 'admin') $count = false;

        if($count) $this->record($request, $u);

        return $next($request, $u);

    }

    private function record(Request $r, $user) {

//        dd($_SERVER);

//        dd(isset($_SERVER['REDIRECT_URL']) ? $_SERVER['REDIRECT_URL'] : '/');

        $urn = isset($_SERVER['REDIRECT_URL']) ? $_SERVER['REDIRECT_URL'] : '/';

        if($user === null) $userId = 0;
        else $userId = $user->id;

        if($v = Visit::where('page', $urn)->first()) {
            $v->increment('amount');
        } else {
            $v = new Visit();
            $v->page = $urn;
            $v->user = $userId;
            $v->amount = 1;
            $v->save();
        }
        $d = date('Y/m/d');
        if($dv = DailyVisit::where('date', $d)->first()) {
            $dv->increment('amount');
        } else {
            $visit = new DailyVisit();
            $visit->date = $d;
            $visit->amount = 1;
            $visit->save();
        }
    }
}
