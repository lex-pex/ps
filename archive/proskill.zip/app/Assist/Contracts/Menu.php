<?php


namespace App\Assist\Contracts;


interface Menu
{
    public function feed();
}