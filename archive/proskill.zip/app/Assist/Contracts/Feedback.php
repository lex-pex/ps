<?php

namespace App\Assist\Contracts;


interface Feedback
{
    function newMessages();
}