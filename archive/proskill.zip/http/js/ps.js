function sb_toggle() {
    if (document.getElementById("sidebar").style.display === "block") {
        document.getElementById("sidebar").style.display = "none";
        document.getElementById("btn-toggler").className = "fa fa-bars";
    }
    else {
        document.getElementById("sidebar").style.display = "block";
        document.getElementById("sidebar").focus();
        document.getElementById("btn-toggler").className = "fa fa-times";
    }
}
