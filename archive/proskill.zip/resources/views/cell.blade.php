<!DOCTYPE html>
<html lang="ru"><head>
    <title>{{ $headers['pageTitle'] }}</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="{{ URL::asset('proger-skill-favicon.png') }}" type="image/x-icon">
    <link rel="stylesheet" href="{{ URL::asset('css/ps.css') }}">
    <link rel="stylesheet" href="{{ URL::asset('css/sb.css') }}">
    <link rel="stylesheet" href="{{ URL::asset('css/app.css') }}">
    <link rel="stylesheet" href="{{ URL::asset('css/fa/css/fa.min.css')}}">
    <link rel="stylesheet" href="{{ URL::asset('/css/font/ub.css')}}">
    <meta property="og:type"          content="website" />
    <meta property="og:image"         content="{{ $headers['image'] ? $headers['image'] : '/img/def/def.jpg' }}" />
    <meta property="og:title"         content="{{ $headers['title'] }}" />
    <meta property="og:description"   content="{{ $headers['description'] }}" />
    <meta property="og:url"           content="{{ asset($headers['url']) }}" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@vegansfreedom.com" />
    <meta name="twitter:title" content="{{ $headers['title'] }}" />
    <meta name="twitter:description" content="{{ $headers['image'] ? $headers['image'] : '/img/def/def.jpg' }}" />
    <meta name="twitter:image" content="{{ $headers['image'] }}" />
    <style> body{background:url('/img/bg/box.png')}</style>
</head>
<body>
@include('parts.menu')
<main role="main">
@include('parts.cell.jumbo')
<div class="container-fluid m-0">
<div class="row">
<div class="col-lg-1 text-center ps-btns">
    {{--<div class="btn btn-info">Hello</div>--}}
    <span><img src="/img/btns/1.png"/></span>
    <span><img src="/img/btns/2.png"/></span>
    <span><img src="/img/btns/3.png"/></span>
    <span><img src="/img/btns/4.png"/></span>
</div>
<div class="col-lg-8 col-md-9 col-sm-12 col-xs-12">
<div class="row">
    <div class="col-12 p-0">
        <div class="ps-header">
            <img src="{{ $headers['image'] ? $headers['image'] : '/img/def/def.jpg' }}" style="position:absolute;left:0;top:0;width:100%;" />
            <div class="shade"></div>
            <div class="offset-lg-1 col-lg-10 offset-md-1 col-md-10 col-sm-12">
                <h1>{{ $headers['title'] }}</h1>
                <p style="font-size:17px;padding:15px">{{ $headers['description'] }}</p>
                <div class="ps-path">
                @php $slash = ''@endphp
                @foreach(isset($path) ? $path : [] as $key => $value)
                    <i style="color:silver">{{$slash}}</i> <a href="/{{ $value }}">{{ $key }}</a>
                    @php $slash = '/'@endphp
                @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
@yield('feed')
</div>
<div class="col-lg-3 col-md-3">
@include('parts.cell.rb')
</div>
</div>
</main>
@include('parts.footer')
<script src="/js/jq.js"></script>
<script src="/js/bs.js"></script>
<script src="/js/ps.js"></script>
</body>
</html>
