@extends('cell')
@section('feed'){{--<div class="row"><div class="col-12 p-0"><img src="{{ $group->image ? $group->image : '/img/def/def.jpg' }}" style="width:100%"></div></div>--}}
@if($group->text)<div class="row"><div class="col-12 p-0">{!! $group->text !!}</div></div>@endif
@php $odd = 0; @endphp
@foreach($items as $item)
@if($odd++ % 2 == 0)<div class="row">@endif
<div class="col-lg-6 col-md-6 p-0">
    <div class="ps-card offset-lg-1 col-lg-10 offset-md-1 col-md-10 col-sm-12 col-xs-12 p-0">
        <a href="/{{ $headers['url'] . '/' . $item->alias }}">
            <img src="{{ $item->image ? $item->image : '/img/def/def.jpg' }}" style="width: 100%"/>
            <div class="p-1">
                <h2>{{ $item->name }}</h2>
                <hr/>
                <p>{{ $item->description }}</p>
            </div>
        </a>
    </div>
</div>
@if($odd % 2 == 0)</div>@endif @endforeach
@if($odd % 2 != 0)
<div class="col-lg-6 col-md-6 p-0">
    <div class="ps-card offset-lg-1 col-lg-10 offset-md-1 col-md-10 col-sm-12 col-xs-12 p-0">
        <code>реклама</code>
        <a href="https://vegansfreedom.com/health/effektivnaya_dieta_pri_prostude" target="_blank">
            <img src="/img/adv/diet.jpg" style="width:100%"/>
            <div class="p-1">
                <h2>Диета при простуде</h2>
                <p>Сезон простуды, все бегут в аптеку за пилюлями, чудо таблетками, надеясь на быстрое выздоровление. Конечно, они мог......</p>
            </div>
        </a>
    </div>
</div>
</div>
@endif
<div class="row"><div class="ps-after col-12 p-0"><div class="ps-carbon"></div></div></div>
@endsection