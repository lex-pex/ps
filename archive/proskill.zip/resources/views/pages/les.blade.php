@extends('cell')
@section('feed')
<div class="row">
<div class="col-12 p-0 bg-white mt-3 mb-3">
<div class="ps-txt" style="padding:10px">{!! $lesson->text !!}</div>
</div>
</div>
<div class="row"><div class="ps-after col-12 p-0"><div class="ps-carbon"></div></div></div>
@endsection