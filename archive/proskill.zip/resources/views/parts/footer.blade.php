<footer class="footer bg-dark text-left text-muted" style="border-top:5px solid silver">
    <div class="container-fluid">
        <div class="row p-3">
            <div class="col-md-4">
                Java Basics <br/>
                Java OOP <br/>
                Java Multithreading
            </div>
            <div class="col-md-4">
                Java Generics <br/>
                Java GUI <br/>
                Java Applets
            </div>
            <div class="col-md-4">
                Java Desctop <br/>
                Java Collections <br/>
                Java Data Base
            </div>
        </div>
        <hr/>
        <div class="text-center">&copy; Proger Skill 2018</div>
    </div>
</footer>